#include "MovieManager.h"

int main()
{
	bool run = true;
	MovieManager runningProgram;

	while (run == true)
	{
		runningProgram.run();
		
	}
	return 0;
}
